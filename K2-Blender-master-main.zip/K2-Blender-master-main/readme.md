
<h3 align="center">For Blender 4.0+</h3>

Install

> [!NOTE]
> https://youtu.be/b_3bqIRgvoE?si=EA6K0KBLTOSdc9-_

<hr/>

<h3 align="center">All errors have been fixed. Hoho, I think so, yeah.</h3>

If you encounter any errors, please let me know.
<br/>
